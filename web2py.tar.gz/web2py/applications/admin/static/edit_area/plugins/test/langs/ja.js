editArea.add_lang("ja",{
test_select: "select tag",
test_but: "test button"
});
